﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace WebApplication2
{
    public partial class popular : System.Web.UI.Page
    {
        string connectionString = db.connectionString;
        public Boolean isLoggedIn = false;
        public string cat_name;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session.Contents.Count > 0)
            {
                isLoggedIn = true;
            }
            
            if (!string.IsNullOrEmpty(Request.QueryString["cat"]))
            {
                cat_name = Request.QueryString["cat"];
                //category = searchTerm;
            }

        }
    }
}