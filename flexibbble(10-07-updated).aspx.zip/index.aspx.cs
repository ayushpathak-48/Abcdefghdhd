﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public partial class index : System.Web.UI.Page
    {
        string connectionString = "server=localhost;database=flexibbble;uid=root;pwd=90Ayushpathak@;";
        public Boolean isLoggedIn = false;
       
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected  void getuser()
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                string query = "SELECT * FROM users where email='" + Session["email"] + "';";
                MySqlCommand command = new MySqlCommand(query, connection);
                connection.Open();
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int id = reader.GetInt32("id");
                        nameLetter.InnerText= reader.GetString("name");
                        nameLetter.InnerHtml = reader.GetString("name").Substring(0,1); 
                    }
                }
            }
        }

    }
}