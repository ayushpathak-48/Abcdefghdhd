﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string connectionString = db.connectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btn_register_Click(object sender, EventArgs e)
        {
            string email = reg_email.Value;
            string name = reg_name.Value;
            string pwd = reg_pwd.Value;
            string cpwd= reg_cpwd.Value;
            string pattern = @"^[a-z][a-z|0-9|]*([_][a-z|0-9]+)*([.][a-z|0-9]+([_][a-z|0-9]+)*)?@[a-z][a-z|0-9|]*\.([a-z][a-z|0-9]*(\.[a-z][a-z|0-9]*)?)$";
            Match match = Regex.Match(email.Trim(), pattern, RegexOptions.IgnoreCase);
            if (name.Trim() == "" || pwd.Trim() == "" || cpwd.Trim() == "" || email.Trim()=="" || pwd != cpwd)
            {
                if (email.Trim() == "")
                {
                    err_email.InnerText = Convert.ToString("Email is Required");
                }
                else
                {
                    if (!match.Success)
                    {
                        err_email.InnerText = Convert.ToString("Enter a valid email");
                    }
                    else
                    {
                        err_email.InnerText = String.Empty;
                    }
                }
                if (pwd.Trim() == "")
                {
                    err_pwd.InnerText = Convert.ToString("Password is Required");
                }
                else
                {
                    err_pwd.InnerText = String.Empty;
                }
                if (cpwd.Trim() == "")
                {
                    err_cpwd.InnerText = Convert.ToString("Confirm Password is Required");
                }
                else
                {
                    err_cpwd.InnerText = String.Empty;
                }
                if (name.Trim() == "")
                {
                    err_name.InnerText = Convert.ToString("Name is Required");
                }
                else
                {
                    err_name.InnerText = String.Empty;
                }

                if (pwd != cpwd && pwd !="" && cpwd != "")
                {
                    err_cpwd.InnerText = Convert.ToString("Password & Confirm Password Doesn't Match");
                }
                else
                {
                    err_cpwd.InnerText = String.Empty;
                }

            }
            else
            {
                err_pwd.InnerText = String.Empty;
                err_email.InnerText = String.Empty;
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    string query = "SELECT * FROM users where email='" + email + "';";
                    MySqlCommand command = new MySqlCommand(query, connection);
                    connection.Open();
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            err_email.InnerText+= Convert.ToString("Email Already taken");
                        }
                        else
                        {
                           signup(email,name,pwd);
                        }
                    }
                }
            }
        }

        private void signup(string email, string name, string pwd)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                string query = "INSERT INTO `users`(`email`, `name`, `password`, `role`, `status`) VALUES ('"+email+"','"+name+"','"+pwd+"','1','1');";
                MySqlCommand command = new MySqlCommand(query, connection);
                connection.Open(); 
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.RecordsAffected > 0)
                    {
                        Session["email"] = email;
                        Session["signup"] = true;
                        Response.Redirect("login.aspx");
                    }
                    else
                    {
                        error_field.InnerText = Convert.ToString("Something Went Wrong!");
                    }
                }
            }
        }
      
    }
}