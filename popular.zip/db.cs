﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace WebApplication2
{
    public class db
    {
        public static string  connectionString = "server=217.21.85.103;database=u168330358_flexibbble;uid=u168330358_flexibbble;pwd=90Ayushpathak@;";
    }
}