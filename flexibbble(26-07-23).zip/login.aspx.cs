﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace WebApplication2
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        string connectionString = db.connectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session.Contents.Count > 0)
            {
                foreach (string key in Session.Contents)
                {
                    string value = "Key: " + key + ", Value: " + Session[key].ToString();
                    if (key == "loggedIn")
                    {
                         Response.Redirect("/");
                    }
                    if (key == "email")
                    {
                        login_email.Value = Session[key].ToString();
                    }
                    if (key == "signup")
                    {
                        success_text.InnerText = Convert.ToString("Signed Up Successfully Now Login to Continue");
                    }
                }
            }
            Session.Contents.Remove("signup");
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            Session.Contents.Remove("signup");
            string val = login_email.Value;
            string pattern = @"^[a-z][a-z|0-9|]*([_][a-z|0-9]+)*([.][a-z|0-9]+([_][a-z|0-9]+)*)?@[a-z][a-z|0-9|]*\.([a-z][a-z|0-9]*(\.[a-z][a-z|0-9]*)?)$";
            Match match = Regex.Match(val.Trim(), pattern, RegexOptions.IgnoreCase);
            if (login_email.Value.Trim() == "" || login_pwd.Value.Trim() == "")
            {
                if (login_email.Value.Trim() == "")
                {
                    err_email.InnerText = Convert.ToString("Email is Required");
                }
                else
                {
                    if (!match.Success)
                    {
                        err_email.InnerText = Convert.ToString("Enter a valid email");
                    }
                    else
                    {
                        err_email.InnerText = String.Empty;
                    }
                }
                if (login_pwd.Value.Trim() == "")
                {
                    err_pwd.InnerText = Convert.ToString("Password is Required");
                }
                else
                {
                    err_pwd.InnerText = String.Empty;
                }
            }else
            {
                err_pwd.InnerText = String.Empty;
                err_email.InnerText = String.Empty;
                using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                string query = "SELECT * FROM users where email='" + login_email.Value + "' and password ='" + login_pwd.Value + "';";
                MySqlCommand command = new MySqlCommand(query, connection);
                connection.Open();
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.HasRows) {
                        while (reader.Read())
                        {
                            Session["email"] = reader.GetString("email");
                            Session["loggedIn"] = true;
                            Response.Redirect("/");
                        }
                    }
                    else
                    {
                        error_field.InnerText = Convert.ToString("Invalid Email or Password");
                    }
                }
             }
            }
        }
    }
    }
